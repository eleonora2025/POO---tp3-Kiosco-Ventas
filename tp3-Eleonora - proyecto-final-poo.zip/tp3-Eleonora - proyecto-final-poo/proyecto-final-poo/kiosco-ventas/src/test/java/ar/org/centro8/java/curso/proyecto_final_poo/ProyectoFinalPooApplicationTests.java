package ar.org.centro8.java.curso.proyecto_final_poo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalPooApplicationTests {

	@Test
	void contextLoads() {
	}

}
